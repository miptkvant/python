import threading
import time


class Screwdriver:
    def __init__(self, number):
        self.number = number
        self.lock = threading.Lock()

    def __enter__(self):
        self.lock.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.lock.release()


class Doctor(threading.Thread):
    def __init__(self, number, left_screwdriver, right_screwdriver, barrier):
        threading.Thread.__init__(self)
        self.number = number
        self.left_screwdriver = min(left_screwdriver, right_screwdriver, key=lambda x: x.number)
        self.right_screwdriver = max(left_screwdriver, right_screwdriver, key=lambda x: x.number)
        self.barrier = barrier

    def blast(self):
        print(f"Doctor {self.number}: BLAST!")

    def run(self):
        while True:
            with self.left_screwdriver:
                with self.right_screwdriver:
                    self.blast()
            self.barrier.wait()
            time.sleep(2)


def main():
    screwdrivers = [Screwdriver(i) for i in range(5)]
    barrier = threading.Barrier(5)

    doctors = []
    for i in range(5):
        left_screwdriver = screwdrivers[i]
        right_screwdriver = screwdrivers[(i + 1) % 5]
        doctor = Doctor(i + 9, left_screwdriver, right_screwdriver, barrier)
        doctors.append(doctor)
        doctor.start()
    for doctor in doctors:
        doctor.join()


if __name__ == "__main__":
    main()