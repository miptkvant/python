from urllib.parse import parse_qs
from wsgiref.simple_server import make_server
import json
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s: %(message)s')

class RequestsHandler:
    def __call__(self, environ, start_response):
        method = environ['REQUEST_METHOD']
        if method == 'GET':
            return self.response(environ, start_response)
        else:
            error_descr = 'Method Not Allowed'
            return self.form_response({'error': error_descr}, 405, 'Method Not Allowed', start_response)

    def response(self, environ, start_response):
        status_code = 404
        message = "Not Found"
        response_data = {'error': message }
        query_params = parse_qs(environ['QUERY_STRING'])
        species = query_params.get('species', [None])[0]
        if environ['PATH_INFO'] == '/' and len(query_params) == 1 and species is not None:
            credentials_dict = {
                'Cyberman': 'John Lumic',
                'Dalek': 'Davros',
                'Judoon': 'Shadow Proclamation Convention 15 Enforcer',
                'Human': 'Leonardo da Vinci',
                'Ood': 'Klineman Halpen',
                'Silence': 'Tasha Lem',
                'Slitheen': 'Coca-Cola salesman',
                'Sontaran': 'General Staal',
                'Time Lord': 'Rassilon',
                'Weeping Angel': 'The Division Representative',
                'Zygon': 'Broton'
            }
            credentials = credentials_dict.get(species, 'Unknown')
            if (credentials != "Unknown"):
                status_code = 200
                message = "OK"    
            response_data = {'credentials': credentials}
        return self.form_response(response_data, status_code, message, start_response)
    

    def form_response(self, response_data, status_code, message, start_response):
        response = json.dumps(response_data)
        start_response(f'{status_code} {message}', [('Content-type', 'application/json')])
        return [response.encode('utf-8')]

if __name__ == '__main__':
    try:
        addr = '127.0.0.1'
        port = 8888
        server = make_server(addr, port, RequestsHandler())
        logging.info(f'Starting server on {addr}:{port}...')
        server.serve_forever()
    except Exception as ex:
        logging.error(str(ex))

