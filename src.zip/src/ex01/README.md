### Commands

pip3 install flask

python3 app.py OR flask --app src/ex01/app.py run --host=127.0.0.1 --port=8888 

Cntrl + C for exit