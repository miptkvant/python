import os
from flask import Flask, render_template, request, redirect, url_for, jsonify
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s: %(message)s')

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'sound_files')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def get_files():
    sound_files = []
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        if check_file(filename):
            sound_files.append(filename)
    return sound_files

def check_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ['ogg', 'wav', 'mp3']

def get_mime_type(filename):
    mime_types = {
        'mp3': 'audio/mpeg',
        'ogg': 'audio/ogg',
        'wav': 'audio/wav'
    }
    extension = filename.rsplit('.', 1)[1].lower()
    return mime_types.get(extension)


@app.route('/', methods=['GET'])
def home():
    sound_files = get_files()
    return render_template('index.html', files=sound_files, get_mime_type=get_mime_type)

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    if is_sound_file(file):
        filename = file.filename
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    elif not file:
        return "The file was not selected", 400
    else:
        return "Non-audio file detected", 400
    return redirect(url_for('home'))

@app.route('/list', methods=['GET'])
def list_files():
    sound_files = get_files()
    response = jsonify(sound_files)
    response.headers['Content-Type'] = 'application/json; charset=utf-8'
    return response


def is_sound_file(file):
    allowed_mimetypes = ['audio/mpeg', 'audio/ogg', 'audio/wav']
    logging.info("file MIME type:", str(file.mimetype))
    return file.mimetype in allowed_mimetypes


if __name__ == '__main__':
    app.run(port=8888)