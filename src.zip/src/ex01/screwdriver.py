
import os
import argparse
import logging
import mimetypes
import requests


logging.basicConfig(level=logging.INFO, format='%(asctime)s: %(message)s')

UPLOAD_URL = 'http://localhost:8888/upload'
LIST_URL = 'http://localhost:8888/list'

def upload(path_to_file):
    file = {'file': (os.path.basename(path_to_file), open(path_to_file, 'rb'), mimetypes.guess_type(path_to_file)[0])}
    response = requests.post('http://localhost:8888/upload', files=file)
    if response.status_code == 200:
        logging.info(f'File was successfully uploaded: {path_to_file}')
    else:
        logging.error('The download failed, the file may have the wrong type.')


def list():
    response = requests.get(LIST_URL)
    if response.status_code == 200:
        files = response.json()
        if not files:
            print('There are no files on the server')
        else:
            print('Files:')
        for file in files:
            print(file)
    else:
        logging.error("An error occurred when requesting a list of files: " + str(response.status_code))


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(prog='screwdriver.py')
        command_parser = parser.add_subparsers(dest='command', required=True)
        command_parser.add_parser('list')
        upload_parser = command_parser.add_parser('upload')
        upload_parser.add_argument('file', help='Path to the audio file')
        args = parser.parse_args()

        if args.command == 'upload':
            upload(args.file)
        elif args.command == 'list':
            list()
    except Exception as ex:
        logging.error(str(ex))